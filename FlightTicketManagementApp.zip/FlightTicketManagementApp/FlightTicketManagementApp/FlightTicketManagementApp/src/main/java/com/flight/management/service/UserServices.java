package com.flight.management.service;

public interface UserServices {
    public boolean isLoggedIn(String name,String email);
}
