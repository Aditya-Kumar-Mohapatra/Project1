package com.flight.management.service.impl;

import com.flight.management.datamodel.UserModel;
import com.flight.management.service.UserServices;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

@Service
public class UserServicesImpl implements UserServices {
    public static String userDetailsCsv = "data/user_data.csv";
    public static List<UserModel> userDetails = new ArrayList<>();


    public UserServicesImpl() {
        ClassPathResource resource = new ClassPathResource(userDetailsCsv);
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line, ",");
                while (tokenizer.hasMoreTokens()) {
                    UserModel model = new UserModel();
                    model.setUserEmail(tokenizer.nextToken());
                    model.setUserPassword(tokenizer.nextToken());
                    userDetails.add(model);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean isLoggedIn(String email, String password) {
        if (!userDetails.isEmpty()) {
            for (UserModel userModel : userDetails) {
                if (userModel.getUserEmail().equals(email) && userModel.getUserPassword().equals(password)) {
                    return true;
                }
            }
        }
        return false;
    }
}
