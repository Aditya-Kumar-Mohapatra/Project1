package com.flight.management.service;

import com.flight.management.datamodel.FlightDataReaderModel;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
@Component
public class DataReader {
    public static String flightDetailsCsv = "data/flight_data.csv";
    public static List<FlightDataReaderModel> flightDetails = new ArrayList<>();


    public DataReader(){
        ClassPathResource resource = new ClassPathResource(flightDetailsCsv);
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()));
            String line;
            int i =0;
            while ((line = reader.readLine()) != null) {
                if(i == 0){
                    i++;
                    continue;
                }
                StringTokenizer tokenizer = new StringTokenizer(line, ",");
                while (tokenizer.hasMoreTokens()) {
                    FlightDataReaderModel model = new FlightDataReaderModel();
                    model.setFlight_no(tokenizer.nextToken());
                    model.setFlight_name(tokenizer.nextToken());
                    model.setCountry(tokenizer.nextToken());
                    model.setFrom(tokenizer.nextToken());
                    model.setTo(tokenizer.nextToken());
                    model.setDate(tokenizer.nextToken());
                    model.setPrice(tokenizer.nextToken());
                    model.setClasses(tokenizer.nextToken());
                    model.setCount(i);
                    flightDetails.add(model);
                }
                i++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
