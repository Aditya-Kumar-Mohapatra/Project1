package com.flight.management.controller;

import com.flight.management.service.DataReader;
import com.flight.management.service.UserServices;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WebController {

    @Autowired
    UserServices userServices;

    @GetMapping("/")
    public ModelAndView home(HttpSession httpSession) {
        if (null != httpSession && httpSession.getAttribute("email") != null) {
            ModelAndView modelAndView = new ModelAndView();
            modelAndView.setViewName("index.html");
            return modelAndView;
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index.html");
        modelAndView.addObject("user_mail", httpSession.getAttribute("email"));
        modelAndView.addObject("flight_data", DataReader.flightDetails);
        return modelAndView;
    }

    @GetMapping("/flightstatus")
    public ModelAndView flightStatus(HttpSession httpSession) {
        if (null != httpSession && httpSession.getAttribute("email") != null) {
            ModelAndView modelAndView = new ModelAndView();
            modelAndView.setViewName("flight_status.html");
            return modelAndView;
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login.html");
        return modelAndView;
    }

    @PostMapping("/login")
    public ModelAndView login(HttpSession httpSession, @RequestParam("email") String email, @RequestParam("password") String password, HttpServletResponse response) {
        if (null != httpSession && httpSession.getAttribute("email") != null) {
            ModelAndView modelAndView = new ModelAndView();
            modelAndView.setViewName("login.html");
            return modelAndView;
        }
        if (userServices.isLoggedIn(email, password)) {
            response.setStatus(200);
            response.setHeader("Location", "/");
            return null;
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login.html");
        modelAndView.addObject("error","User does not exist or creds are not valid.");
        return modelAndView;
    }

    @GetMapping("/signup")
    public ModelAndView signup(HttpSession httpSession) {
        if (null != httpSession && httpSession.getAttribute("email") != null) {
            ModelAndView modelAndView = new ModelAndView();
            modelAndView.setViewName("register.html");
            return modelAndView;
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login.html");
        return modelAndView;
    }

    @GetMapping("/logout")
    public ModelAndView logout(HttpSession httpSession) {
        httpSession.removeAttribute("email");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login.html");
        return modelAndView;
    }
}
